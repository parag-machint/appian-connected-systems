/**
 * 
 */
package com.machint.appian.csp.alfresco.cms.templates;

import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.simplified.sdk.connectiontesting.SimpleTestableConnectedSystemTemplate;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.Choice;
import com.appian.connectedsystems.templateframework.sdk.connectiontesting.TestConnectionResult;

/**
 * @author Parag Ranjan
 *
 */

@TemplateId(name = "AlfrescoCMSConnectedSystemTemplate", majorVersion = 1)
public class AlfrescoCMSConnectedSystemTemplate extends SimpleTestableConnectedSystemTemplate
{
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String AUTH_TYPE = "auth-type";
	public static final Choice[] AUTH_TYPES = 
		{
	      new Choice.ChoiceBuilder().name("Basic Auth").value("basic-auth").build()
	    };
	
	@Override
	protected SimpleConfiguration getConfiguration(SimpleConfiguration simpleConfiguration, ExecutionContext executionContext) 
	{
		return simpleConfiguration.setProperties(textProperty(AUTH_TYPE).label("Authentication Type").choices(AUTH_TYPES).isRequired(true).placeholder("---Select Authentication Type---").build(),
				textProperty(USERNAME).label("Username").isImportCustomizable(true).isRequired(true).placeholder("---Enter Username---").build(),
				encryptedTextProperty(PASSWORD).label("Password").isImportCustomizable(true).isRequired(true).placeholder("---Enter Password---").masked(true).build());
	}
	
	@Override
	protected TestConnectionResult testConnection(SimpleConfiguration simpleConfiguration, ExecutionContext executionContext) 
	{
		return null;
	}	
}

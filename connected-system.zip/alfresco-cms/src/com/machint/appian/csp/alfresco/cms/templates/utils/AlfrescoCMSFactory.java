/**
 * 
 */
package com.machint.appian.csp.alfresco.cms.templates.utils;

import java.util.logging.Logger;

/**
 * @author Parag Ranjan
 *
 */
public class AlfrescoCMSFactory 
{
	private static final Logger LOG = Logger.getLogger(AlfrescoCMSFactory.class.toString());  
}

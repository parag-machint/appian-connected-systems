/**
 * 
 */
package com.machint.appian.csp.alfresco.cms.templates;

/**
 * @author Parag Ranjan
 *
 */
public class AlfrescoCMSCreateFolderIntegrationTemplate 
{

}

package com.appian.ps.awsS3.templates;

import java.util.Map;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CreateBucketRequest;
import com.amazonaws.services.s3.model.GetBucketLocationRequest;
import com.appian.connectedsystems.simplified.sdk.SimpleIntegrationTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyPath;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateRequestPolicy;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateType;
import com.appian.ps.awsS3.templates.s3util.IntegrationExecution;
import com.appian.ps.awsS3.templates.std.Diagnostics;
import com.appian.ps.awsS3.templates.std.Util;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;

@TemplateId(name = "AWSS3CreateBucketIntegrationTemplate")
@IntegrationTemplateType(IntegrationTemplateRequestPolicy.WRITE)
public class AWSS3CreateBucketIntegrationTemplate extends SimpleIntegrationTemplate {

  public static final String BUCKET_NAME_KEY = "bucketName";
  String[] stringKeyArray = {BUCKET_NAME_KEY};

  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      PropertyPath propertyPath,
      ExecutionContext executionContext) {

    return integrationConfiguration.setProperties(
        textProperty(BUCKET_NAME_KEY).label("Bucket Name")
            .isRequired(true)
            .isExpressionable(true)
            .build());
  }

  @Override
  protected IntegrationResponse execute(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      ExecutionContext executionContext) {

    Diagnostics diagnostics = new Diagnostics();
    diagnostics.startTiming();

    Map<String, String> valueMap = Util.getStringMap(integrationConfiguration, stringKeyArray);
    diagnostics.addAll(valueMap);

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    try {

      String bucketName = valueMap.get(BUCKET_NAME_KEY);

      if (s3Client.doesBucketExistV2(bucketName)) {
        return IntegrationExecution.handleExistingBucketException();
      }

      Bucket bucket = s3Client.createBucket(new CreateBucketRequest(bucketName));

      // Verify that the bucket was created by retrieving it and checking its location.
      String bucketLocation = s3Client.getBucketLocation(new GetBucketLocationRequest(bucketName));

      return Util.buildSuccess(diagnostics, IntegrationExecution.getBucketResult(bucket,bucketLocation));

    } catch (AmazonServiceException e) {

      // The call was transmitted successfully, but Amazon S3 couldn't process
      // it and returned an error response.
      e.printStackTrace();

      return IntegrationExecution.handleAmazonServiceException(e);

    } catch (SdkClientException e) {
      // Amazon S3 couldn't be contacted for a response, or the client
      // couldn't parse the response from Amazon S3.
      e.printStackTrace();

      return IntegrationExecution.handleAmazonSDKException(e);

    } catch (Exception e) {

      return Util.buildFailure(diagnostics, "Integration Execution Error", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");

    } finally {

      s3Client.shutdown();

    }

  }

}


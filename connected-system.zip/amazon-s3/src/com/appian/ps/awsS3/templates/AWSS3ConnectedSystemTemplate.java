package com.appian.ps.awsS3.templates;

import com.amazonaws.services.s3.AmazonS3;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.simplified.sdk.connectiontesting.SimpleTestableConnectedSystemTemplate;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.Choice;
import com.appian.connectedsystems.templateframework.sdk.connectiontesting.TestConnectionResult;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;

@TemplateId(name = "AWSS3ConnectedSystemTemplate", majorVersion = 2)
public class AWSS3ConnectedSystemTemplate extends SimpleTestableConnectedSystemTemplate {

  public static final String ACCESS_KEY_ID = "accessKeyId";
  public static final String SECRET_ACCESS_KEY = "secretAccessKey";
  public static final String REGION = "region";
  public static final Choice[] REGIONS = {
      new Choice.ChoiceBuilder().name("US West (Oregon) Region").value("us-west-2").build(),
      new Choice.ChoiceBuilder().name("US West (N. California) Region").value("us-west-1").build(),
      new Choice.ChoiceBuilder().name("US East (Ohio) Region").value("us-east-2").build(),
      new Choice.ChoiceBuilder().name("US East (N. Virginia) Region").value("us-east-1").build(),
      new Choice.ChoiceBuilder().name("Asia Pacific (Mumbai) Region").value("ap-south-1").build(),
      new Choice.ChoiceBuilder().name("Asia Pacific (Seoul) Region").value("ap-northeast-2").build(),
      new Choice.ChoiceBuilder().name("Asia Pacific (Singapore) Region").value("ap-southeast-1").build(),
      new Choice.ChoiceBuilder().name("Asia Pacific (Sydney) Region").value("ap-southeast-2").build(),
      new Choice.ChoiceBuilder().name("Asia Pacific (Tokyo) Region").value("ap-northeast-1").build(),
      new Choice.ChoiceBuilder().name("Canada (Central) Region").value("ca-central-1").build(),
      new Choice.ChoiceBuilder().name("China (Beijing) Region").value("cn-north-1").build(),
      new Choice.ChoiceBuilder().name("EU (Frankfurt) Region").value("eu-central-1").build(),
      new Choice.ChoiceBuilder().name("EU (Ireland) Region").value("eu-west-1").build(),
      new Choice.ChoiceBuilder().name("EU (London) Region").value("eu-west-2").build(),
      new Choice.ChoiceBuilder().name("EU (Paris) Region").value("eu-west-3").build(),
      new Choice.ChoiceBuilder().name("South America (São Paulo) Region").value("sa-east-1").build(),
      new Choice.ChoiceBuilder().name("AWS GovCloud (US)").value("us-gov-west-1").build()};

  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration simpleConfiguration, ExecutionContext executionContext) {
    return simpleConfiguration.setProperties(
        textProperty(ACCESS_KEY_ID).label("Access Key Id").isImportCustomizable(true).instructionText("You can find this info at: https://console.aws.amazon.com/iam/home ").build(),
        textProperty(REGION).label("Region").choices(REGIONS).build(),
        encryptedTextProperty(SECRET_ACCESS_KEY).label("Secret Access Key")
            .isImportCustomizable(true)
            .build());
  }

  @Override
  protected TestConnectionResult testConnection(
      SimpleConfiguration simpleConfiguration, ExecutionContext executionContext) {

    AmazonS3 s3Client = AmazonS3Factory.create(simpleConfiguration, executionContext);

    try {

      s3Client.getS3AccountOwner();

      return TestConnectionResult.success();

    } catch (Exception e) {

      return TestConnectionResult.error(e.getMessage());

    } finally {

      s3Client.shutdown();

    }

  }

}

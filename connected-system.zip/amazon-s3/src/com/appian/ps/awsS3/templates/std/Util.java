package com.appian.ps.awsS3.templates.std;

import java.util.HashMap;
import java.util.Map;

import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.IntegrationError;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.diagnostics.IntegrationDesignerDiagnostic;

public class Util {

  public static Map<String, String> getStringMap(SimpleConfiguration integrationConfiguration, String[] keyArray) {
    Map<String, String> keyValueMap = new HashMap<>();
    for (String key : keyArray) {
      try {
        keyValueMap.put(key, integrationConfiguration.getValue(key));
      }catch(Exception e){
        System.out.println("Could not get value: " + key + ": " + e.getMessage());
        keyValueMap.put(key,"");
      }
    }
    return keyValueMap;
  }

  public static IntegrationResponse buildSuccess(Diagnostics diagnostics, Map<String, Object> returnValues) {
    long time = Math.abs(diagnostics.getTiming());
    final IntegrationDesignerDiagnostic diagnostic = IntegrationDesignerDiagnostic.builder()
        .addExecutionTimeDiagnostic(time)
        .addRequestDiagnostic(diagnostics.getDiagnostics())
        .build();

    return IntegrationResponse
        .forSuccess(returnValues)
        .withDiagnostic(diagnostic)
        .build();
  }

  public static IntegrationResponse buildFailure(Diagnostics diagnostics, String title, String detail, String message, String guidance) {
    long time = Math.abs(diagnostics.getTiming());
    final IntegrationDesignerDiagnostic diagnostic = IntegrationDesignerDiagnostic.builder()
        .addExecutionTimeDiagnostic(time)
        .addRequestDiagnostic(diagnostics.getDiagnostics())
        .build();

    return IntegrationResponse.forError(
        new IntegrationError.IntegrationErrorBuilder().title(title)
            .detail(detail)
            .message(message)
            .detail(guidance).build()).withDiagnostic(diagnostic).build();
  }
}

package com.appian.ps.awsS3.templates;

import java.util.HashMap;
import java.util.Map;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.AmazonS3Exception;
import com.amazonaws.services.s3.model.S3Object;
import com.appian.connectedsystems.simplified.sdk.SimpleIntegrationTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyPath;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateRequestPolicy;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateType;
import com.appian.ps.awsS3.templates.std.Diagnostics;
import com.appian.ps.awsS3.templates.std.Util;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;

@TemplateId(name = "AWSS3DeleteFileIntegrationTemplate")
@IntegrationTemplateType(IntegrationTemplateRequestPolicy.WRITE)
public class AWSS3DeleteFileIntegrationTemplate extends SimpleIntegrationTemplate {

  public static final String BUCKET_NAME_KEY = "bucketName";
  public static final String FILE_PATH_KEY = "filePath";
  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      PropertyPath propertyPath,
      ExecutionContext executionContext) {

    return integrationConfiguration.setProperties(
        textProperty(BUCKET_NAME_KEY).label("Bucket Name").isRequired(true).isExpressionable(true).build(),
        textProperty(FILE_PATH_KEY).label("File Path").isRequired(true).isExpressionable(true).build());
  }

  @Override
  protected IntegrationResponse execute(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      ExecutionContext executionContext) {

    Diagnostics diagnostics = new Diagnostics();
    diagnostics.startTiming();

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    try {

      String bucketName = integrationConfiguration.getValue(BUCKET_NAME_KEY);
      String filePath = integrationConfiguration.getValue(FILE_PATH_KEY);

      s3Client.deleteObject(bucketName, filePath);

      diagnostics.stopTiming();
      // Verify that the object was deleted by retrieving it and receiving 400 exception

      try {
        Map<String,Object> result = new HashMap<>();
        result.put("success", true);
        return Util.buildSuccess(diagnostics, result);
      } catch (AmazonS3Exception e) {
        S3Object object = s3Client.getObject(bucketName, filePath);
        return Util.buildFailure(diagnostics, "The file could not be deleted",
            "Error Code: " + e.getErrorCode(), e.getMessage(),
            "Please check if the file exists and that you have proper permissions to remove.");
      }

    } catch (Exception e) {

      return Util.buildFailure(diagnostics, "Integration Execution Error", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");

    } finally {

      s3Client.shutdown();

    }
  }

}


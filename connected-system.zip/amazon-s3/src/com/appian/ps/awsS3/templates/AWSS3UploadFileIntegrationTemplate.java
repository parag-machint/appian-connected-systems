package com.appian.ps.awsS3.templates;

import java.io.InputStream;
import java.util.Map;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.S3ResponseMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;
import com.appian.connectedsystems.simplified.sdk.SimpleIntegrationTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.Document;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyPath;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateRequestPolicy;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateType;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;
import com.appian.ps.awsS3.templates.s3util.IntegrationExecution;
import com.appian.ps.awsS3.templates.std.Diagnostics;
import com.appian.ps.awsS3.templates.std.Util;

@TemplateId(name = "AWSS3UploadFileIntegrationTemplate")
@IntegrationTemplateType(IntegrationTemplateRequestPolicy.WRITE)
public class AWSS3UploadFileIntegrationTemplate extends SimpleIntegrationTemplate {

  public static final String FILE_KEY = "fileId";
  public static final String FILE_PATH_KEY = "filePath";
  public static final String FILE_NAME_KEY = "fileName";
  public static final String BUCKET_KEY = "bucketName";
  public static final String IS_PUBLIC_KEY = "isPublic";
  public static final String USES_ENCRYPTION_KEY = "usesEncryptionKey";
  public static final String CONTENT_TYPE = "contentType";

  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      PropertyPath propertyPath,
      ExecutionContext executionContext) {

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    return integrationConfiguration.setProperties(
        //Document Property allows the user to select a document in Appian to send to AWS S3
        documentProperty(FILE_KEY).label("File").isRequired(true).instructionText("File size limit of 5GB").build(),
        textProperty(FILE_NAME_KEY).label("File Name").isExpressionable(true)
            .instructionText("If left blank, the document's Appian name will be used instead")
            .build(),
        textProperty(BUCKET_KEY).label("Bucket").isExpressionable(true)
            .choices(IntegrationExecution.createBucketChoices(s3Client))
            .isRequired(true)
            .build(),
        textProperty(FILE_PATH_KEY).label("File Path").isExpressionable(true)
            .instructionText("If left blank, the document will be uploaded to the root of the bucket")
            .build(),
        textProperty(CONTENT_TYPE).label("File Content-Type").isExpressionable(true)
            .instructionText("If left blank, the content-type will default to application/octet-stream")
            .build(),
        booleanProperty(IS_PUBLIC_KEY).isExpressionable(true)
            .label("Public")
            .build(),
        booleanProperty(USES_ENCRYPTION_KEY).isExpressionable(true)
            .label("Encrypted")
            .build()

    );
  }

  @Override
  protected IntegrationResponse execute(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      ExecutionContext executionContext) {

    Diagnostics diagnostics = new Diagnostics();
    diagnostics.startTiming();

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);
    TransferManager tm = TransferManagerBuilder.standard().withS3Client(s3Client).build();

    Document document = integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.FILE_KEY);
    try(InputStream inputStream = document.getInputStream()) {

      PutObjectRequest request = IntegrationExecution.buildRequest(integrationConfiguration,document);
      request.withInputStream(inputStream);

      Upload upload = tm.upload(request);
      S3ResponseMetadata responseMetadata = s3Client.getCachedResponseMetadata(request);
      diagnostics.add("Cloud Front Id:", responseMetadata == null ? "" : responseMetadata.getCloudFrontId());
      diagnostics.add("Host Id:", responseMetadata == null ? "" : responseMetadata.getHostId());
      diagnostics.add("Request Id:", responseMetadata == null ? "" : responseMetadata.getRequestId());
      upload.waitForCompletion();
      diagnostics.stopTiming();

      Map<String,Object> result = IntegrationExecution.getFileUploadResult(upload);

      result.put("url", s3Client.getUrl(integrationConfiguration.getValue(BUCKET_KEY), integrationConfiguration.getValue(FILE_NAME_KEY)));

      return Util.buildSuccess(diagnostics, result);

    } catch (Exception e) {

      e.printStackTrace();

      return Util.buildFailure(diagnostics, "Integration Execution Error", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");

    } finally {

      s3Client.shutdown();
      tm.shutdownNow();
    }
  }

}


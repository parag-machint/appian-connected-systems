package com.appian.ps.awsS3.templates.s3util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.ListObjectsV2Result;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.util.IOUtils;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.IntegrationError;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.configuration.Choice;
import com.appian.connectedsystems.templateframework.sdk.configuration.Document;
import com.appian.ps.awsS3.templates.AWSS3ConnectedSystemTemplate;
import com.appian.ps.awsS3.templates.AWSS3CreateBucketIntegrationTemplate;
import com.appian.ps.awsS3.templates.AWSS3ListObjectsIntegrationTemplate;
import com.appian.ps.awsS3.templates.AWSS3UploadFileIntegrationTemplate;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class IntegrationExecution {
  private IntegrationExecution() {
  }

  final static int[] illegalChars = {34, 60, 62, 124, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 58, 42, 63, 92, 47};
  static {
    Arrays.sort(illegalChars);
  }
  final static Gson gson = new GsonBuilder().setPrettyPrinting().create();
  /**
   * Files
   */

  /**
   * This information will be shown in the Result Tab. These keys can also be keyed off in the Process Modeler
   * when executing the integration.
   */
  public static Map<String,Object> getFileUploadResult(Upload upload) {
    Map<String,Object> result = new HashMap<>();
    result.put("desc", upload.getDescription());
    result.put("percentTransfered", upload.getProgress().getPercentTransferred());
    result.put("status", upload.isDone() ? "SUCCESS" : "FAIL");
    result.put("statusCode", 200);
    return result;
  }

  /**
   * This information will be shown in the Result Tab. These keys can also be keyed off in the Process Modeler
   * when executing the integration.
   */
  public static Map<String,Object> getMultiFileUploadResult(MultipleFileUpload upload) {
    Map<String,Object> result = new HashMap<>();
    result.put("desc", upload.getDescription());
    result.put("percentTransfered", upload.getProgress().getPercentTransferred());
    result.put("status", upload.isDone() ? "SUCCESS" : "FAIL");
    result.put("statusCode", 200);
    return result;
  }

  public static PutObjectRequest buildRequest(SimpleConfiguration integrationConfiguration, Document document) throws Exception {

    String fileName =  getNameForDocument(document, integrationConfiguration);
    String filePath = getFilePath(
        integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.FILE_PATH_KEY));
    String bucketName = integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.BUCKET_KEY);
    String contentType = integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.CONTENT_TYPE);
    if(contentType == null || contentType.isEmpty()){
      contentType = "application/octet-stream";
    }
    Boolean isPublic = integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.IS_PUBLIC_KEY);
    Boolean usesEncryption = integrationConfiguration.getValue(
        AWSS3UploadFileIntegrationTemplate.USES_ENCRYPTION_KEY);

    ObjectMetadata metadata = new ObjectMetadata();

    metadata.setContentType(contentType);

    if (usesEncryption) {
      metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
    }

    PutObjectRequest request = new PutObjectRequest(bucketName, filePath + fileName,
        null, metadata);

    if (isPublic) {
      request.setCannedAcl(CannedAccessControlList.PublicRead);
    }

    return request;
  }

  //Returns a file name if it's provided, otherwise use's the document's Appian name
  public static String getNameForDocument(Document document, SimpleConfiguration integrationConfiguration) {
    String documentNameFromUserInput = integrationConfiguration.getValue(
        AWSS3UploadFileIntegrationTemplate.FILE_NAME_KEY);
    if (documentNameFromUserInput != null && !documentNameFromUserInput.isEmpty()) {
      return cleanFileName(documentNameFromUserInput) + "." + document.getExtension();
    } else {
      return cleanFileName(document.getFileName());
    }
  }

  public static String getFilePath(String filePath) {
    if (filePath == null || filePath.isEmpty()) {
      return "";
    }
    if (!filePath.endsWith("/")) {
      filePath = filePath + "/";
    }
    if (filePath.startsWith("/")) {
      filePath = filePath.replaceFirst("/", "");
    }
    return filePath;
  }

  public static Map<String, Object> generateTemporaryFile(Document document, File tempDirectory, String newName)
    throws IOException {

    try{
      Map<String, Object> fileMap = new HashMap<>();
      InputStream inputStream = document.getInputStream();
      File tempFile;
      if ((newName != null) && (!newName.trim().equals(""))) {
        tempFile = new File(tempDirectory, newName);
      } else {
        tempFile = new File(tempDirectory, document.getFileName());
	  }
      tempFile.deleteOnExit();

      OutputStream output = new FileOutputStream(tempFile);

      IOUtils.copy(inputStream, output);
      fileMap.put("file", tempFile);
      fileMap.put("stream", inputStream);

      return fileMap;

    } catch (IOException e) {
      throw new IOException();
    }

  }

  public static File generateTemporaryDirectory() throws IOException{
    try{
      Path tempDirectory = Files.createTempDirectory(null);
      tempDirectory.toFile().deleteOnExit();
      return tempDirectory.toFile();
    }
    catch (Exception e){
      throw new IOException();
    }

  }

  public static void closeStreams(List<InputStream> streams){
    streams.forEach(stream -> {
      try {
        stream.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    });
  }
  /**
   * Buckets
   */

  public static Choice[] createBucketChoices(AmazonS3 s3Client) {

    List<Bucket> buckets = s3Client.listBuckets();

    return buckets.stream().map(bucket -> {
      String bucketName = bucket.getName();
      return Choice.builder().name(bucketName).value(bucketName).build();
    }).toArray(Choice[]::new);
  }

  /**
   * This information will be shown in the Result Tab. These keys can also be keyed off in the Process Modeler
   * when executing the integration.
   */
  public static Map<String,Object> getBucketResult(Bucket bucket, String bucketLocation) {
    Map<String,Object> result = new HashMap<>();
    result.put("bucketName", bucket.getName());
    result.put("createdOn", bucket.getCreationDate());
    result.put("bucketLocation", bucketLocation);
    result.put("status", "SUCCESS");
    return result;
  }

  /**
   * This information will be shown in the Result Tab. These keys can also be keyed off in the Process Modeler
   * when executing the integration.
   */
  public static Map<String,Object> listBucketResult(List<Bucket> buckets) {
    Map<String,Object> result = new HashMap<>();
    List<Object> bucketNameValueList = new ArrayList<>();

    for (Bucket bucket : buckets) {
      bucketNameValueList.add(gson.toJson(bucket));
    }

    result.put("buckets", bucketNameValueList);
    result.put("count", buckets.size());
    result.put("status", "SUCCESS");
    return result;
  }

  /**
   * Objects
   */
  public static List<S3ObjectSummary> getObjects(
      AmazonS3 s3Client,
      SimpleConfiguration integrationConfiguration) {
    ListObjectsV2Result result = s3Client.listObjectsV2(
        integrationConfiguration.getValue(AWSS3ListObjectsIntegrationTemplate.BUCKET_NAME_KEY),
        integrationConfiguration.getValue(AWSS3ListObjectsIntegrationTemplate.PREFIX_KEY));
    return result.getObjectSummaries();
  }

  /**
   * This information will be shown in the Result Tab. These keys can also be keyed off in the Process Modeler
   * when executing the integration.
   */
  public static Map<String,Object> listObjectsResult(String bucketName, List<S3ObjectSummary> summaries, AmazonS3 s3Client) {
    Map<String,Object> result = new HashMap<>();

    result.put("bucket", bucketName);
    List<Map<String,Object>> objects = new ArrayList<>();

    for (S3ObjectSummary summary : summaries) {
      Map<String, Object> objectSummary = new HashMap<>();
      objectSummary.put("URL", s3Client.getUrl(bucketName, summary.getKey()));
      objectSummary.put("bucketName", summary.getBucketName());
      objectSummary.put("storageClass", summary.getStorageClass());
      objectSummary.put("size", summary.getSize());
      objectSummary.put("lastModified", summary.getLastModified());
      objectSummary.put("ETag", summary.getETag());
      objectSummary.put("key", summary.getKey());
      objects.add(objectSummary);
    }
    result.put("objects", objects);
    result.put("count", objects.size());
    result.put("status", "SUCCESS");
    return result;
  }
  /**
   *  Exceptions
   */

  /**
   * Returns an IntegrationResponse error because the bucket already exists
   */
  public static IntegrationResponse handleExistingBucketException() {

    IntegrationError error = IntegrationError.builder()
        .title("Bucket Already Exists")
        .message("Cannot add bucket since it has already been created.")
        .build();

    return IntegrationResponse.forError(error).build();
  }

  /**
   * Handles Amazon's {@link AmazonServiceException}. You can add custom logic for handling
   * specific errors, such as building a IntegrationResponse with different error messages for a
   * particular error code.
   */
  public static IntegrationResponse handleAmazonServiceException(
      AmazonServiceException e) {

    if (e.getStatusCode() == 401) {
      throw new AmazonServiceException(e.getErrorMessage());
    }

    IntegrationError error = IntegrationError.builder()
        .title("Amazon Service Exception Status: " + e.getErrorMessage())
        .message(e.getMessage())
        .build();

    return IntegrationResponse.forError(error).build();
  }

  /**
   * Handles Amazon's {@link SdkClientException}. You can add custom logic for handling
   * specific errors, such as building a IntegrationResponse with different error messages for a
   * particular error code.
   */
  public static IntegrationResponse handleAmazonSDKException(
      SdkClientException e) {

    IntegrationError error = IntegrationError.builder()
        .title("Amazon SDK Status: " + e.getMessage())
        .message(e.getMessage())
        .build();

    return IntegrationResponse.forError(error).build();
  }

  /**
   * Creates common fields of diagnostics objects for both Send File and Create Folder templates.
   * Diagnostic is information that will be displayed in the Request and Response tabs. You can
   * include information that is helpful for the developer to debug, such as HTTP parameters.
   */
  public static Map<String,Object> getRequestDiagnostics(SimpleConfiguration connectedSystemConfiguration) {
    Map<String,Object> requestDiagnostic = new HashMap<>();
    //Request Diagnostic values will be shown on the Request tab on Appian Integration Designer Interface,
    //which will be visible to designers. Only add to diagnostics values that you wish the designer to see.
    String accessKey = connectedSystemConfiguration.getValue(
        AWSS3ConnectedSystemTemplate.ACCESS_KEY_ID);
    requestDiagnostic.put(AWSS3ConnectedSystemTemplate.ACCESS_KEY_ID, accessKey);
    //For sensitive values, mask it so that it won't be visible to designers
    requestDiagnostic.put(AWSS3ConnectedSystemTemplate.SECRET_ACCESS_KEY, "******************");
    return requestDiagnostic;
  }

  /**
   * Creates response diagnostics for both {@link AWSS3UploadFileIntegrationTemplate} and
   * {@link AWSS3CreateBucketIntegrationTemplate}
   */
  public static Map<String,String> getResponseDiagnostics(Bucket bucket) {
    Map<String,String> responseDiagnostic = new HashMap<>();
    responseDiagnostic.put("Name", bucket.getName());
    responseDiagnostic.put("ID", Integer.toString(bucket.hashCode()));
    return responseDiagnostic;
  }

  /**
   * Creates response diagnostics for both {@link AWSS3UploadFileIntegrationTemplate} and
   * {@link AWSS3CreateBucketIntegrationTemplate}
   */
  public static Map<String,String> getResponseDiagnostics(List<Bucket> buckets) {
    Map<String,String> responseDiagnostic = new HashMap<>();
    responseDiagnostic.put("Size", Integer.toString(buckets.size()));
    return responseDiagnostic;
  }

  public static String cleanFileName(String badFileName) {
    StringBuilder cleanName = new StringBuilder();
    for (int i = 0; i < badFileName.length(); i++) {
      int c = (int)badFileName.charAt(i);
      if (Arrays.binarySearch(illegalChars, c) < 0) {
        cleanName.append((char)c);
      }
    }
    return cleanName.toString();
  }
}

package com.appian.ps.awsS3.templates;

import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.Bucket;
import com.appian.connectedsystems.simplified.sdk.SimpleIntegrationTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyPath;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateRequestPolicy;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateType;
import com.appian.ps.awsS3.templates.s3util.IntegrationExecution;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;
import com.appian.ps.awsS3.templates.std.Diagnostics;
import com.appian.ps.awsS3.templates.std.Util;

@TemplateId(name = "AWSS3ListBucketsIntegrationTemplate")
@IntegrationTemplateType(IntegrationTemplateRequestPolicy.READ)
public class AWSS3ListBucketsIntegrationTemplate extends SimpleIntegrationTemplate {
  private static final Logger LOG = Logger.getLogger("AWSS3CreateBucketIntegrationTemplate");

  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      PropertyPath propertyPath,
      ExecutionContext executionContext) {

    return integrationConfiguration;
  }

  @Override
  protected IntegrationResponse execute(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      ExecutionContext executionContext) {

    Diagnostics diagnostics = new Diagnostics();
    diagnostics.startTiming();

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    try {

      List<Bucket> buckets = s3Client.listBuckets();

      diagnostics.stopTiming();

      Map<String,Object> result = IntegrationExecution.listBucketResult(buckets);

      return Util.buildSuccess(diagnostics, result);

    } catch (AmazonServiceException e) {

      // The call was transmitted successfully, but Amazon S3 couldn't process
      // it and returned an error response.
      e.printStackTrace();

      return IntegrationExecution.handleAmazonServiceException(e);

    } catch (SdkClientException e) {
      // Amazon S3 couldn't be contacted for a response, or the client
      // couldn't parse the response from Amazon S3.
      e.printStackTrace();

      return IntegrationExecution.handleAmazonSDKException(e);

    } catch (Exception e) {

      return Util.buildFailure(diagnostics, "Integration Execution Error", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");

    } finally {

      s3Client.shutdown();

    }
  }

}

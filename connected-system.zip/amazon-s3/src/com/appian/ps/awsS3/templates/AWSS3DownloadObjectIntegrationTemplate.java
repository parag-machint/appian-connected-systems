package com.appian.ps.awsS3.templates;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.appian.connectedsystems.simplified.sdk.SimpleIntegrationTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.Document;
import com.appian.connectedsystems.templateframework.sdk.configuration.FolderPropertyDescriptor;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyPath;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;
import com.appian.ps.awsS3.templates.s3util.IntegrationExecution;
import com.appian.ps.awsS3.templates.std.Diagnostics;
import com.appian.ps.awsS3.templates.std.Util;

@TemplateId(name = "AWSS3DownloadObjectIntegrationTemplate")
public class AWSS3DownloadObjectIntegrationTemplate extends SimpleIntegrationTemplate {

  public static final String BUCKET_NAME_KEY = "bucketNameKey";
  public static final String OBJECT_KEY = "objectKey";
  public static final String FOLDER_ID_KEY = "folderId";

  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      PropertyPath propertyPath,
      ExecutionContext executionContext) {
    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);
    return integrationConfiguration.setProperties(
        textProperty(BUCKET_NAME_KEY).label("Bucket").isExpressionable(true)
            .choices(IntegrationExecution.createBucketChoices(s3Client))
            .isRequired(true)
            .isExpressionable(true)
            .instructionText("What bucket does the object live in?")
            .build(),
        textProperty(OBJECT_KEY)
            .label("Object Key")
            .isRequired(true)
            .isExpressionable(true)
            .instructionText("This can be found in the shareable link for the file as part of the URL, e.g. " +
                "the 'testphoto.jpeg' part of 'https://appian-test.s3.amazonaws.com/testphoto.jpeg'")
            .build(),
        FolderPropertyDescriptor.builder()
            .key(FOLDER_ID_KEY)
            .label("Save to Appian Folder")
            .isRequired(true)
            .isExpressionable(true)
            .build()
    );
  }

  @Override
  protected IntegrationResponse execute(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      ExecutionContext executionContext) {

    Diagnostics diagnostics = new Diagnostics();
    diagnostics.startTiming();

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    try {
      String bucketName = integrationConfiguration.getValue(BUCKET_NAME_KEY);
      String key = integrationConfiguration.getValue(OBJECT_KEY);

      // Get Appian Folder Id
      // From new Appian Folder Property : FolderPropertyDescriptor.builder()
      Long folderId = integrationConfiguration.getValue(FOLDER_ID_KEY);

      // Get Document InputStream
      S3Object fullObject = null;
      fullObject = s3Client.getObject(new GetObjectRequest(bucketName, key));

      InputStream mediaInputStream = fullObject.getObjectContent();
      String fileName = FilenameUtils.removeExtension(key);
      String fileType = FilenameUtils.getExtension(key);

      // Download Document to Appian Folder
      // Use new SDK Method getDocumentDownloadService
      Document document = executionContext.getDocumentDownloadService()
          .downloadDocument(mediaInputStream, folderId, key);

      // close input stream
      mediaInputStream.close();

      // Build and return successful response
      // Document will now be added to the Appian Folder
      diagnostics.stopTiming();

      Map<String,Object> result = new HashMap<>();
      result.put("Document", document);

      Map<String,Object> responseDiagnostics = new HashMap<>();
      responseDiagnostics.put("File Name", fileName);
      responseDiagnostics.put("File Type", fileType);
      responseDiagnostics.put("Bucket Name", fullObject.getBucketName());
      responseDiagnostics.put("Last Modified", fullObject.getObjectMetadata().getLastModified());
      responseDiagnostics.put("Content Length", fullObject.getObjectMetadata().getContentLength());

      return Util.buildSuccess(diagnostics, result);
    } catch (AmazonServiceException e) {

      // The call was transmitted successfully, but Amazon S3 couldn't process
      // it and returned an error response.
      e.printStackTrace();

      return IntegrationExecution.handleAmazonServiceException(e);

    } catch (SdkClientException e) {
      // Amazon S3 couldn't be contacted for a response, or the client
      // couldn't parse the response from Amazon S3.
      e.printStackTrace();

      return IntegrationExecution.handleAmazonSDKException(e);

    } catch (Exception e) {

      return Util.buildFailure(diagnostics, "Integration Execution Error", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");

    } finally {

      s3Client.shutdown();

    }

  }

}


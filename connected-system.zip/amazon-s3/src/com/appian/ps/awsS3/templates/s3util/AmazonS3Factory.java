package com.appian.ps.awsS3.templates.s3util;

import java.util.logging.Logger;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.ProxyConfigurationData;
import com.appian.ps.awsS3.templates.AWSS3ConnectedSystemTemplate;

public class AmazonS3Factory {
  private static final Logger LOG = Logger.getLogger(AmazonS3Factory.class.toString());
  private static final String S3_HOST_NAME = "s3.amazonaws.com";

  public static AmazonS3 create(SimpleConfiguration simpleConfiguration, ExecutionContext executionContext){
    String accessKey = simpleConfiguration.getValue(AWSS3ConnectedSystemTemplate.ACCESS_KEY_ID);
    String secretAccessKey = simpleConfiguration.getValue(AWSS3ConnectedSystemTemplate.SECRET_ACCESS_KEY);
    String region = simpleConfiguration.getValue(AWSS3ConnectedSystemTemplate.REGION);

    BasicAWSCredentials creds = new BasicAWSCredentials(accessKey, secretAccessKey);

    AmazonS3 s3Client = AmazonS3Client.builder()
        .withClientConfiguration(GetProxyConfig(executionContext.getProxyConfigurationData()))
        .withCredentials(new AWSStaticCredentialsProvider(creds))
        .withRegion(region)
        .build();

    return s3Client;
  }

  private static ClientConfiguration GetProxyConfig(ProxyConfigurationData proxyConfigurationData){
    ClientConfiguration config = new ClientConfiguration();
    if (proxyConfigurationData.isEnabled() && !proxyConfigurationData.isExcludedHost(S3_HOST_NAME)) {
      config.setProtocol(Protocol.HTTPS);
      config.setProxyHost(proxyConfigurationData.getHost());
      config.setProxyPort(proxyConfigurationData.getPort());
      if(proxyConfigurationData.isAuthRequired()){
        config.setProxyUsername(proxyConfigurationData.getUsername());
        config.setProxyPassword(proxyConfigurationData.getPassword());
      }
    }
    return config;
  }

}

package com.appian.ps.awsS3.templates;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.ObjectMetadataProvider;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.appian.connectedsystems.simplified.sdk.SimpleIntegrationTemplate;
import com.appian.connectedsystems.simplified.sdk.configuration.SimpleConfiguration;
import com.appian.connectedsystems.templateframework.sdk.ExecutionContext;
import com.appian.connectedsystems.templateframework.sdk.IntegrationResponse;
import com.appian.connectedsystems.templateframework.sdk.TemplateId;
import com.appian.connectedsystems.templateframework.sdk.configuration.Document;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyPath;
import com.appian.connectedsystems.templateframework.sdk.configuration.PropertyState;
import com.appian.connectedsystems.templateframework.sdk.configuration.SystemType;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateRequestPolicy;
import com.appian.connectedsystems.templateframework.sdk.metadata.IntegrationTemplateType;
import com.appian.ps.awsS3.templates.s3util.AmazonS3Factory;
import com.appian.ps.awsS3.templates.s3util.IntegrationExecution;
import com.appian.ps.awsS3.templates.std.Diagnostics;
import com.appian.ps.awsS3.templates.std.Util;

@TemplateId(name = "AWSS3UploadMultiFileIntegrationTemplate")
@IntegrationTemplateType(IntegrationTemplateRequestPolicy.WRITE)
public class AWSS3UploadMultiFileIntegrationTemplate extends SimpleIntegrationTemplate {

  public static final String FILE_KEYS = "fileIds";
  public static final String FILE_NAME_KEYS = "fileNameKeys";
  public static final String FILE_PATH_KEY = "filePath";
  public static final String BUCKET_KEY = "bucketName";
  public static final String USES_ENCRYPTION_KEY = "usesEncryptionKey";

  @Override
  protected SimpleConfiguration getConfiguration(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      PropertyPath propertyPath,
      ExecutionContext executionContext) {

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    return integrationConfiguration.setProperties(
        listTypeProperty(FILE_KEYS).itemType(SystemType.DOCUMENT).label("Files")
            .instructionText("File size limit of 5TB")
            .isExpressionable(true)
            .isRequired(true)
            .build(),
        listTypeProperty(FILE_NAME_KEYS).itemType(SystemType.STRING).label("File Name(s)")
        	.instructionText("If left blank, the document's Appian name will be used instead")
        	.isExpressionable(true)
            .isRequired(false)
            .build(),
        textProperty(BUCKET_KEY).label("Bucket")
            .choices(IntegrationExecution.createBucketChoices(s3Client))
            .isRequired(true)
            .build(),
        textProperty(FILE_PATH_KEY).label("File Path")
            .instructionText("If left blank, the documents will be uploaded to the root of the bucket")
            .build(),
        booleanProperty(USES_ENCRYPTION_KEY).isExpressionable(true)
            .label("Encrypted")
            .build()
        );
  }

  @Override
  protected IntegrationResponse execute(
      SimpleConfiguration integrationConfiguration,
      SimpleConfiguration connectedSystemConfiguration,
      ExecutionContext executionContext) {

    Diagnostics diagnostics = new Diagnostics();
    diagnostics.startTiming();

    AmazonS3 s3Client = AmazonS3Factory.create(connectedSystemConfiguration, executionContext);

    TransferManager tm = TransferManagerBuilder.standard().withS3Client(s3Client).build();

    List<InputStream> streams = new ArrayList<InputStream>();

    try {

      String bucketName = integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.BUCKET_KEY);
      String filePath = IntegrationExecution.getFilePath(integrationConfiguration.getValue(AWSS3UploadFileIntegrationTemplate.FILE_PATH_KEY));
      ArrayList<PropertyState> propertyStates = integrationConfiguration.getValue(FILE_KEYS);
      ArrayList<PropertyState> fileNamePropertyStates = integrationConfiguration.getValue(FILE_NAME_KEYS);

      List<File> files = new ArrayList<File>();
      File tempDirectory = IntegrationExecution.generateTemporaryDirectory();

      int i =0; 
      for (PropertyState propertyState : propertyStates) { 
    	String fileName = "";
    	
    	if ((fileNamePropertyStates != null) && (fileNamePropertyStates.size() > i)) {
          fileName = (String)fileNamePropertyStates.get(i).getValue();
    	}
    	i++;
        Document document = (Document)propertyState.getValue();

        try {
          Map<String, Object> fileMap = IntegrationExecution.generateTemporaryFile(document, tempDirectory, fileName);
          File file = (File)fileMap.get("file");
          files.add(file);
          streams.add((InputStream)fileMap.get("stream"));
        } catch (IOException e) {
          e.printStackTrace();
          return Util.buildFailure(diagnostics, "Integration Execution Error: Error generating temporary files", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");
        }
      }

      Boolean usesEncryption = integrationConfiguration.getValue(
          AWSS3UploadFileIntegrationTemplate.USES_ENCRYPTION_KEY);

      ObjectMetadataProvider objectMetadataProvider = new ObjectMetadataProvider() {
        public void provideObjectMetadata(File file, ObjectMetadata metadata) {
          if (usesEncryption) {
            metadata.setSSEAlgorithm(ObjectMetadata.AES_256_SERVER_SIDE_ENCRYPTION);
          }
        }
      };

      MultipleFileUpload upload = tm.uploadFileList(bucketName, filePath, tempDirectory, files, objectMetadataProvider);

      upload.waitForCompletion();

      diagnostics.stopTiming();

      return Util.buildSuccess(diagnostics, IntegrationExecution.getMultiFileUploadResult(upload));

    } catch (Exception e) {
    	
      return Util.buildFailure(diagnostics, "Integration Execution Error", e.getClass().getSimpleName(), e.getMessage(), "Please review logs for stack trace.");

    } finally {

      s3Client.shutdown();
      tm.shutdownNow();
      IntegrationExecution.closeStreams(streams);

    }

  }

}
